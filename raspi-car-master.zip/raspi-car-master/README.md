# raspi-car

** control raspi-car with a flask  web controller **

run command like this:

```
python __init__.py
```

and then:

  1. visit http://RASPI-CAR-IP:RASP-CAR-PORT;
  2. input you passwd
  3. enjoy youself!

# TODO

1. buy one camera
2. control the camera :smile: