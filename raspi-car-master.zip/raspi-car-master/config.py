#! /usr/bin/python
# -*- coding:utf-8 -*-

config = {
	"web_pass":"123456",
	"flask_secret_key":"A0Zr08j/3yX R~XHH!jmN]LWX/,?RT"
}